-- MySQL dump 10.13  Distrib 9.4.0, for macos15.4 (arm64)
--
-- Host: 127.0.0.1    Database: oficina
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `ID_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `documento` varchar(20) NOT NULL,
  `id_endereco` int DEFAULT NULL,
  `perfil` enum('administrador','gerencia','usuario_comum') NOT NULL DEFAULT 'usuario_comum',
  `senha` varchar(255) NOT NULL,
  PRIMARY KEY (`ID_cliente`),
  KEY `id_endereco` (`id_endereco`),
  CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`id_endereco`) REFERENCES `enderecos` (`ID_endereco`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Ana Lima','11122233344',1,'administrador','$2y$10$XtlwheklyaqxrmBB6yQpDeG9PEIdaDhwXjvitUu4tinrGL0yri5qe'),(2,'Bruno Souza','22233344455',2,'gerencia','$2y$10$XtlwheklyaqxrmBB6yQpDeG9PEIdaDhwXjvitUu4tinrGL0yri5qe'),(3,'Carla Nunes','33344455566',3,'usuario_comum','$2y$10$XtlwheklyaqxrmBB6yQpDeG9PEIdaDhwXjvitUu4tinrGL0yri5qe');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contato`
--

DROP TABLE IF EXISTS `contato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contato` (
  `ID_contato` int NOT NULL AUTO_INCREMENT,
  `contato` varchar(11) NOT NULL,
  `id_cliente` int DEFAULT NULL,
  PRIMARY KEY (`ID_contato`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `contato_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`ID_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contato`
--

LOCK TABLES `contato` WRITE;
/*!40000 ALTER TABLE `contato` DISABLE KEYS */;
INSERT INTO `contato` VALUES (1,'11999990001',1),(2,'11999990002',2),(3,'11999990003',3);
/*!40000 ALTER TABLE `contato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enderecos`
--

DROP TABLE IF EXISTS `enderecos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enderecos` (
  `ID_endereco` int NOT NULL AUTO_INCREMENT,
  `rua` varchar(100) NOT NULL,
  `numero` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `estado` varchar(100) NOT NULL,
  PRIMARY KEY (`ID_endereco`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enderecos`
--

LOCK TABLES `enderecos` WRITE;
/*!40000 ALTER TABLE `enderecos` DISABLE KEYS */;
INSERT INTO `enderecos` VALUES (1,'Rua das Flores','123','Centro','São Paulo','SP'),(2,'Av. Brasil','456','Jardins','Campinas','SP'),(3,'Rua das Palmeiras','789','Boa Vista','Curitiba','PR');
/*!40000 ALTER TABLE `enderecos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itens_os_pecas`
--

DROP TABLE IF EXISTS `itens_os_pecas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itens_os_pecas` (
  `ID_os` int NOT NULL,
  `ID_peca` int NOT NULL,
  `quantidade` int NOT NULL,
  `preco_venda` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ID_os`,`ID_peca`),
  KEY `ID_peca` (`ID_peca`),
  CONSTRAINT `itens_os_pecas_ibfk_1` FOREIGN KEY (`ID_os`) REFERENCES `ordens_servicos` (`ID_os`),
  CONSTRAINT `itens_os_pecas_ibfk_2` FOREIGN KEY (`ID_peca`) REFERENCES `pecas` (`ID_peca`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens_os_pecas`
--

LOCK TABLES `itens_os_pecas` WRITE;
/*!40000 ALTER TABLE `itens_os_pecas` DISABLE KEYS */;
INSERT INTO `itens_os_pecas` VALUES (1,1,2,40.00),(2,2,1,130.00),(3,3,4,90.00);
/*!40000 ALTER TABLE `itens_os_pecas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itens_os_servicos`
--

DROP TABLE IF EXISTS `itens_os_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itens_os_servicos` (
  `ID_os` int NOT NULL,
  `ID_servico_ref` int NOT NULL,
  `valor_cobrado` decimal(10,2) NOT NULL,
  `diagnostico_tecnico` text NOT NULL,
  PRIMARY KEY (`ID_os`,`ID_servico_ref`),
  KEY `ID_servico_ref` (`ID_servico_ref`),
  CONSTRAINT `itens_os_servicos_ibfk_1` FOREIGN KEY (`ID_os`) REFERENCES `ordens_servicos` (`ID_os`),
  CONSTRAINT `itens_os_servicos_ibfk_2` FOREIGN KEY (`ID_servico_ref`) REFERENCES `servicos_catalagos` (`ID_servico_ref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens_os_servicos`
--

LOCK TABLES `itens_os_servicos` WRITE;
/*!40000 ALTER TABLE `itens_os_servicos` DISABLE KEYS */;
INSERT INTO `itens_os_servicos` VALUES (1,1,160.00,'Óleo muito escuro, troca necessária'),(2,2,110.00,'Pneus com desgaste irregular'),(3,3,520.00,'Revisão dos 50mil km');
/*!40000 ALTER TABLE `itens_os_servicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marcas`
--

DROP TABLE IF EXISTS `marcas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marcas` (
  `ID_marca` int NOT NULL AUTO_INCREMENT,
  `nome_marca` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ID_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marcas`
--

LOCK TABLES `marcas` WRITE;
/*!40000 ALTER TABLE `marcas` DISABLE KEYS */;
INSERT INTO `marcas` VALUES (1,'Toyota'),(2,'Honda'),(3,'Ford');
/*!40000 ALTER TABLE `marcas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanicos`
--

DROP TABLE IF EXISTS `mecanicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mecanicos` (
  `ID_mecanico` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `especialidade` varchar(50) NOT NULL,
  `disponibilidade` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID_mecanico`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanicos`
--

LOCK TABLES `mecanicos` WRITE;
/*!40000 ALTER TABLE `mecanicos` DISABLE KEYS */;
INSERT INTO `mecanicos` VALUES (1,'João Melo','Motor',1),(2,'Pedro Alves','Elétrica',0),(3,'Marcos Silva','Suspensão',1);
/*!40000 ALTER TABLE `mecanicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelos`
--

DROP TABLE IF EXISTS `modelos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modelos` (
  `ID_modelo` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `id_marca` int DEFAULT NULL,
  PRIMARY KEY (`ID_modelo`),
  KEY `id_marca` (`id_marca`),
  CONSTRAINT `modelos_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `marcas` (`ID_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelos`
--

LOCK TABLES `modelos` WRITE;
/*!40000 ALTER TABLE `modelos` DISABLE KEYS */;
INSERT INTO `modelos` VALUES (1,'Corolla',1),(2,'Civic',2),(3,'Ka',3);
/*!40000 ALTER TABLE `modelos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordens_servicos`
--

DROP TABLE IF EXISTS `ordens_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordens_servicos` (
  `ID_os` int NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  `data_abertura` timestamp NOT NULL,
  `data_entrega_prevista` date DEFAULT NULL,
  `garantia_meses` int DEFAULT NULL,
  `id_veiculo` int DEFAULT NULL,
  `id_mecanico` int DEFAULT NULL,
  PRIMARY KEY (`ID_os`),
  KEY `id_veiculo` (`id_veiculo`),
  KEY `id_mecanico` (`id_mecanico`),
  CONSTRAINT `ordens_servicos_ibfk_1` FOREIGN KEY (`id_veiculo`) REFERENCES `veiculos` (`ID_veiculo`),
  CONSTRAINT `ordens_servicos_ibfk_2` FOREIGN KEY (`id_mecanico`) REFERENCES `mecanicos` (`ID_mecanico`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordens_servicos`
--

LOCK TABLES `ordens_servicos` WRITE;
/*!40000 ALTER TABLE `ordens_servicos` DISABLE KEYS */;
INSERT INTO `ordens_servicos` VALUES (1,'aberta','2026-06-15 13:57:04','2025-06-01',3,1,1),(2,'em andamento','2026-06-15 13:57:04','2025-06-05',6,2,2),(3,'concluida','2026-06-15 13:57:04','2025-05-20',12,3,3);
/*!40000 ALTER TABLE `ordens_servicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pecas`
--

DROP TABLE IF EXISTS `pecas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pecas` (
  `ID_peca` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL,
  `nivel_estoque` int NOT NULL,
  PRIMARY KEY (`ID_peca`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pecas`
--

LOCK TABLES `pecas` WRITE;
/*!40000 ALTER TABLE `pecas` DISABLE KEYS */;
INSERT INTO `pecas` VALUES (1,'Filtro de óleo','Filtro para motor 1.0',35.00,50),(2,'Pastilha de freio','Par dianteiro',120.00,30),(3,'Vela de ignição','Jogo com 4 velas',80.00,20);
/*!40000 ALTER TABLE `pecas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicos_catalagos`
--

DROP TABLE IF EXISTS `servicos_catalagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicos_catalagos` (
  `ID_servico_ref` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(205) NOT NULL,
  `preco_base` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ID_servico_ref`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicos_catalagos`
--

LOCK TABLES `servicos_catalagos` WRITE;
/*!40000 ALTER TABLE `servicos_catalagos` DISABLE KEYS */;
INSERT INTO `servicos_catalagos` VALUES (1,'Troca de óleo',150.00),(2,'Alinhamento',100.00),(3,'Revisão completa',500.00);
/*!40000 ALTER TABLE `servicos_catalagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `veiculos`
--

DROP TABLE IF EXISTS `veiculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `veiculos` (
  `ID_veiculo` int NOT NULL AUTO_INCREMENT,
  `placa` varchar(7) NOT NULL,
  `ano` int NOT NULL,
  `id_cliente` int DEFAULT NULL,
  `id_modelo` int DEFAULT NULL,
  PRIMARY KEY (`ID_veiculo`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_modelo` (`id_modelo`),
  CONSTRAINT `veiculos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`ID_cliente`),
  CONSTRAINT `veiculos_ibfk_2` FOREIGN KEY (`id_modelo`) REFERENCES `modelos` (`ID_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `veiculos`
--

LOCK TABLES `veiculos` WRITE;
/*!40000 ALTER TABLE `veiculos` DISABLE KEYS */;
INSERT INTO `veiculos` VALUES (1,'ABC1D23',2020,1,1),(2,'XYZ9E87',2019,2,2),(3,'QWE5F12',2021,3,3);
/*!40000 ALTER TABLE `veiculos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-15 10:57:42
